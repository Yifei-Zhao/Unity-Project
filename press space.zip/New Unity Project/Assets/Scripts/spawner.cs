﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawner : MonoBehaviour {

    public GameObject Pins;


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if(Input.GetKeyDown("space")){
            spawn();

        }
	}

    private void spawn(){
        Instantiate(Pins, transform.position, transform.rotation);
    }
}
